import java.util.Scanner;
class cequation extends chemistry
{
    public void hello()
    {
        System.out.println("               |=================================================================================================|");
        System.out.println("               |                                           CHEMICAL EQUATION                                     |");
        System.out.println("               |=================================================================================================|");
        
        System.out.println("|===================================|");
        System.out.println("|   We are under construction!!!!   |");
        System.out.println("|        We'll be back soon.        |");
        System.out.println("|       Stay tuned till then.       |");
        System.out.println("|===================================|");
        System.out.println("\n"+"\n"+"\n");
        super.menu();
    }
    public static void main()
    {
        cequation h=new cequation();
        h.hello();
    }
}